﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using webdatabase.Models;
using webdatabase.datadb;

namespace webdatabase.Controllers
{
    public class LawyersController : Controller
    {
        private readonly webappdbcontext _context;

        public LawyersController(webappdbcontext context)
        {
            _context = context;
        }

        // GET: Lawyers
        public async Task<IActionResult> Index()
        {
            return View(await _context.Lawyers.ToListAsync());
        }

        // GET: Lawyers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lawyer = await _context.Lawyers
                .FirstOrDefaultAsync(m => m.LawyerId == id);
            if (lawyer == null)
            {
                return NotFound();
            }

            return View(lawyer);
        }

        // GET: Lawyers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Lawyers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LawyerId,Name,Email,Phone,Specialization,DateJoined")] Lawyer lawyer)
        {
          
                _context.Add(lawyer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            
            return View(lawyer);
        }

        // GET: Lawyers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lawyer = await _context.Lawyers.FindAsync(id);
            if (lawyer == null)
            {
                return NotFound();
            }
            return View(lawyer);
        }

        // POST: Lawyers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("LawyerId,Name,Email,Phone,Specialization,DateJoined")] Lawyer lawyer)
        {
            if (id != lawyer.LawyerId)
            {
                return NotFound();
            }

        
                try
                {
                    _context.Update(lawyer);
                    await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));

            }
            catch (DbUpdateConcurrencyException)
                {
                    if (!LawyerExists(lawyer.LawyerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

            return View(lawyer);
        }

        // GET: Lawyers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lawyer = await _context.Lawyers
                .FirstOrDefaultAsync(m => m.LawyerId == id);
            if (lawyer == null)
            {
                return NotFound();
            }

            return View(lawyer);
        }

        // POST: Lawyers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var lawyer = await _context.Lawyers.FindAsync(id);
            if (lawyer != null)
            {
                _context.Lawyers.Remove(lawyer);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LawyerExists(int id)
        {
            return _context.Lawyers.Any(e => e.LawyerId == id);
        }
    }
}
