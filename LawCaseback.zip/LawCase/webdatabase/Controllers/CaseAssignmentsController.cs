﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using webdatabase.Models;
using webdatabase.datadb;

namespace webdatabase.Controllers
{
    public class CaseAssignmentsController : Controller
    {
        private readonly webappdbcontext _context;

        public CaseAssignmentsController(webappdbcontext context)
        {
            _context = context;
        }

        // GET: CaseAssignments
        public async Task<IActionResult> Index()
        {
            var webappdbcontext = _context.CaseAssignments.Include(c => c.Case).Include(c => c.Lawyer);
            return View(await webappdbcontext.ToListAsync());
        }

        // GET: CaseAssignments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var caseAssignment = await _context.CaseAssignments
                .Include(c => c.Case)
                .Include(c => c.Lawyer)
                .FirstOrDefaultAsync(m => m.AssignmentId == id);
            if (caseAssignment == null)
            {
                return NotFound();
            }

            return View(caseAssignment);
        }

        // GET: CaseAssignments/Create
        public IActionResult Create()
        {
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId");
            ViewData["LawyerId"] = new SelectList(_context.Lawyers, "LawyerId", "LawyerId");
            return View();
        }

        // POST: CaseAssignments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AssignmentId,CaseId,LawyerId,AssignedDate")] CaseAssignment caseAssignment)
        {
        
                _context.Add(caseAssignment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId", caseAssignment.CaseId);
            ViewData["LawyerId"] = new SelectList(_context.Lawyers, "LawyerId", "LawyerId", caseAssignment.LawyerId);
            return View(caseAssignment);
        }

        // GET: CaseAssignments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var caseAssignment = await _context.CaseAssignments.FindAsync(id);
            if (caseAssignment == null)
            {
                return NotFound();
            }
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId", caseAssignment.CaseId);
            ViewData["LawyerId"] = new SelectList(_context.Lawyers, "LawyerId", "LawyerId", caseAssignment.LawyerId);
            return View(caseAssignment);
        }

        // POST: CaseAssignments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AssignmentId,CaseId,LawyerId,AssignedDate")] CaseAssignment caseAssignment)
        {
            if (id != caseAssignment.AssignmentId)
            {
                return NotFound();
            }

           try
                {
                    _context.Update(caseAssignment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CaseAssignmentExists(caseAssignment.AssignmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId", caseAssignment.CaseId);
            ViewData["LawyerId"] = new SelectList(_context.Lawyers, "LawyerId", "LawyerId", caseAssignment.LawyerId);
            return View(caseAssignment);
        }

        // GET: CaseAssignments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var caseAssignment = await _context.CaseAssignments
                .Include(c => c.Case)
                .Include(c => c.Lawyer)
                .FirstOrDefaultAsync(m => m.AssignmentId == id);
            if (caseAssignment == null)
            {
                return NotFound();
            }

            return View(caseAssignment);
        }

        // POST: CaseAssignments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var caseAssignment = await _context.CaseAssignments.FindAsync(id);
            if (caseAssignment != null)
            {
                _context.CaseAssignments.Remove(caseAssignment);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CaseAssignmentExists(int id)
        {
            return _context.CaseAssignments.Any(e => e.AssignmentId == id);
        }
    }
}
