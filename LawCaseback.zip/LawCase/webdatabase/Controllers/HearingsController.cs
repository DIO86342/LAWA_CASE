﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using webdatabase.Models;
using webdatabase.datadb;

namespace webdatabase.Controllers
{
    public class HearingsController : Controller
    {
        private readonly webappdbcontext _context;

        public HearingsController(webappdbcontext context)
        {
            _context = context;
        }

        // GET: Hearings
        public async Task<IActionResult> Index()
        {
            var webappdbcontext = _context.Hearings.Include(h => h.Case);
            return View(await webappdbcontext.ToListAsync());
        }

        // GET: Hearings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hearing = await _context.Hearings
                .Include(h => h.Case)
                .FirstOrDefaultAsync(m => m.HearingId == id);
            if (hearing == null)
            {
                return NotFound();
            }

            return View(hearing);
        }

        // GET: Hearings/Create
        public IActionResult Create()
        {
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId");
            return View();
        }

        // POST: Hearings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("HearingId,CaseId,HearingDate,Outcome,Notes")] Hearing hearing)
        {
       
                _context.Add(hearing);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId", hearing.CaseId);
            return View(hearing);
        }

        // GET: Hearings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hearing = await _context.Hearings.FindAsync(id);
            if (hearing == null)
            {
                return NotFound();
            }
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId", hearing.CaseId);
            return View(hearing);
        }

        // POST: Hearings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("HearingId,CaseId,HearingDate,Outcome,Notes")] Hearing hearing)
        {
            if (id != hearing.HearingId)
            {
                return NotFound();
            }

        
                try
                {
                    _context.Update(hearing);
                    await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));

            }
            catch (DbUpdateConcurrencyException)
                {
                    if (!HearingExists(hearing.HearingId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                
            }
            ViewData["CaseId"] = new SelectList(_context.Cases, "CaseId", "CaseId", hearing.CaseId);
            return View(hearing);
        }

        // GET: Hearings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hearing = await _context.Hearings
                .Include(h => h.Case)
                .FirstOrDefaultAsync(m => m.HearingId == id);
            if (hearing == null)
            {
                return NotFound();
            }

            return View(hearing);
        }

        // POST: Hearings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var hearing = await _context.Hearings.FindAsync(id);
            if (hearing != null)
            {
                _context.Hearings.Remove(hearing);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HearingExists(int id)
        {
            return _context.Hearings.Any(e => e.HearingId == id);
        }
    }
}
