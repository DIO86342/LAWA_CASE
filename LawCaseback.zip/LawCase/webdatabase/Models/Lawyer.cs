﻿namespace webdatabase.Models
{
    public class Lawyer
    {
        public int LawyerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Specialization { get; set; }
        public DateTime DateJoined { get; set; }

        public ICollection<CaseAssignment> CaseAssignments { get; set; }
    }
}
