﻿namespace webdatabase.Models
{
    public class Case
    {
        public int CaseId { get; set; } // Primary Key
        public string Title { get; set; }
        public string Description { get; set; }
        public string CaseType { get; set; }
        public string Status { get; set; }
        public int ClientId { get; set; } // Foreign Key to Client
        public Clients Clients { get; set; } // Navigation property


        public ICollection<CaseAssignment> CaseAssignments { get; set; }
        public ICollection<Hearing> Hearings { get; set; }
    }
}
