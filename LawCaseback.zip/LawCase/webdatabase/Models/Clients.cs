﻿namespace webdatabase.Models
{
    public class Clients
    {
        public int ClientId { get; set; } // Primary Key
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public DateTime DateCreated { get; set; }

        public ICollection<Case> Cases { get; set; } = new List<Case>(); // Navigation property

    }
}
