﻿namespace webdatabase.Models
{
    public class CaseAssignment
    {

        public int AssignmentId { get; set; }
        public int CaseId { get; set; }
        public Case Case { get; set; }
        public int LawyerId { get; set; }
        public Lawyer Lawyer { get; set; }
        public DateTime AssignedDate { get; set; }

    }
}
