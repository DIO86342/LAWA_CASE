﻿namespace webdatabase.Models
{
    public class Hearing
    {
        public int HearingId { get; set; }
        public int CaseId { get; set; }
        public Case Case { get; set; }
        public DateTime HearingDate { get; set; }
        public string Outcome { get; set; }
        public string Notes { get; set; }
    }
}
