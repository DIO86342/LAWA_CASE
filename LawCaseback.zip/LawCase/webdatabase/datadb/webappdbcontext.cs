﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using webdatabase.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace webdatabase.datadb
{
    public class webappdbcontext : IdentityDbContext
    {
        public webappdbcontext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Clients> Clients { get; set; }
        public DbSet<Case> Cases { get; set; }
        public DbSet<Lawyer> Lawyers { get; set; }
        public DbSet<CaseAssignment> CaseAssignments { get; set; }
        public DbSet<Hearing> Hearings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Clients>()
        .HasKey(c => c.ClientId); // Explicitly set the primary key

            // Configure Client-Case relationship (One-to-Many)
            modelBuilder.Entity<Clients>()
          .HasMany(c => c.Cases) // A client can have many cases
          .WithOne(c => c.Clients) // Each case belongs to one client
          .HasForeignKey(c => c.ClientId) // Foreign key in Case pointing to Client
          .OnDelete(DeleteBehavior.Cascade); // Cascade delete when a client is deleted

            // Configure Case-Lawyer relationship (Many-to-Many via CaseAssignments)
            modelBuilder.Entity<CaseAssignment>()
                .HasKey(ca => ca.AssignmentId);

            modelBuilder.Entity<CaseAssignment>()
                .HasOne(ca => ca.Case)
                .WithMany(c => c.CaseAssignments)
                .HasForeignKey(ca => ca.CaseId);

            modelBuilder.Entity<CaseAssignment>()
                .HasOne(ca => ca.Lawyer)
                .WithMany(l => l.CaseAssignments)
                .HasForeignKey(ca => ca.LawyerId);

            // Configure Case-Hearing relationship (One-to-Many)
            modelBuilder.Entity<Case>()
                .HasMany(c => c.Hearings)
                .WithOne(h => h.Case)
                .HasForeignKey(h => h.CaseId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }

    }
}
