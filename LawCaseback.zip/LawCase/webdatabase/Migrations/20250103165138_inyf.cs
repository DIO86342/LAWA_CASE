﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webdatabase.Migrations
{
    /// <inheritdoc />
    public partial class inyf : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
